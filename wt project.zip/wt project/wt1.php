<!DOCTYPE html>
<html>  
<head>
    <link href="bootstrap-5.3.0-dist/css/bootstrap.min.css" rel="stylesheet" >
<script src="bootstrap-5.3.0-dist/js/bootstrap.bundle.min.js"></script>
<style>
  .text{
    color: black;
  }
</style>
</head>
<body>
<div class="navbar  navbar-expand-sm fixed-top"  style="background-color:tan">
    <div class="navbar-brand me-auto"><img src="logo1.jpeg"  style="width:50px; height:50px ;">
    <marquee direction="left" behavior="scroll" style="color:purple;font-size: 20px;font-style: oblique;text-shadow:2px 2px 4px white"><b>CHOOSE PRODUCTS THAT SUPPORT YOUR WELLNESS AND HELP YOU FEEL GORGEOUS</b></marquee>
</div>
    <ul class="navbar-nav">
      <li class="nav-item"><a href="" class="nav-link " data-bs-target="#offcanvas" data-bs-toggle="offcanvas"><b>About Us</b></a></li>
        <li class="nav-item dropdown me-3">
            <button class=" btn  dropdown-toggle" data-bs-toggle="dropdown"><b>Buy products</b></button>
            <ul class="dropdown-menu" id="demo">
                <li><a href="skin.html" class="dropdown-item">skin care</a></li>
               
                <li><a href="hair.html" class="dropdown-item">Hair care</a></li>
                <li><a href="makeup.html" class="dropdown-item">Makeup</a></li>

            </ul>
        </li>
        
        
    </ul>
</div>
<div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="carousel" style="width:100%;margin-top:78px;height:578px;">
  <div class="carousel-indicators">
    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1" aria-label="Slide 2"></button>
    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2" aria-label="Slide 3"></button>
  </div>
  <div class="carousel-inner" style="width:100%;height:100%">
    <div class="carousel-item active" style="width:100%;height:100%">
      <img src="1.jpeg" class="d-block" alt="..." style="width:100%;height:100%;">
      <div class="carousel-caption d-none d-md-block">
        <h5>First slide label</h5>
        <p>Some representative placeholder content for the first slide.</p>
      </div>
    </div>
    <div class="carousel-item">
      <img src="b1.jpg" class="d-block" alt="..." style="width:100%;height:100%;">
      <div class="carousel-caption d-none d-md-block">
        <h5>Second slide label</h5>
        <p>Some representative placeholder content for the second slide.</p>
      </div>
    </div>
    <div class="carousel-item">
      <img src="3.jpg" class="d-block w-100" alt="..." style="width:100%;height:100%;">
      <div class="carousel-caption d-none d-md-block">
        <h5>Third slide label</h5>
        <p>Some representative placeholder content for the third slide.</p>
      </div>
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>
    
<div class="offcanvas offcanvas-start text" data-bs-scroll="true"  id="offcanvas" style="background-image:url('pink.jpeg');">
  <div class="offcanvas-header">
    <h5 class="offcanvas-title" id="offcanvasWithBothOptionsLabel">AKBEAUTY Website</h5>
    <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
  </div>
  <div class="offcanvas-body">
    Hello  everyone , i am akhila  .I want to explain a  information about this website.It is small website and it is very useful to us.We are selling beauty product that are very natural,organic and ecofriendly products. 
  <div class="accordion" id="accordionExample">
  <div class="accordion-item">
    <h2 class="accordion-header">
      <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne1" aria-expanded="true" aria-controls="collapseOne">
        Collaberated
      </button>
    </h2>
    <div id="collapseOne1" class="accordion-collapse collapse " data-bs-parent="#accordionExample">
      <div class="accordion-body">
        <strong>  we are Collaberated with popular websites purple and nyka </strong> 
      </div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header">
      <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
        EXPERIENCE 
      </button>
    </h2>
    <div id="collapseOne" class="accordion-collapse collapse " data-bs-parent="#accordionExample">
      <div class="accordion-body">
        <strong> we have only 7 years of experience</strong> 
      </div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header">
      <button class="accordion-button " type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
        Locations
      </button>
    </h2>
    <div id="collapseTwo" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
      <div class="accordion-body">
        <strong>we can delivery product worldwide . free delivery  on above Rs:399</strong>
      </div>
    </div>
  </div>
  </div>
</div>
</body>
</html>